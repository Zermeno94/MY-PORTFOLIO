// work in progres.
//trying to create a splash to portfolio 

//let intro = document.querySelector('.intro');
//let logo= document.querySelector('.logo-header');
//let logo= document.querySelector('.miranda-logo');

//window.addEventListener('DOMContentLoaded', ()=>{

    //setTimeout(()=>{
        //logoSpan.forEach((span,idx) => {
            //setTimeout((){
                //span.classList.add('active');
            //}, (idx + 1) * 400)
        // });
        // setTimeout(()=>{
            // logoSpan.forEach((span,idx)=>{
                // setTimeout(()=>{
                    // span.classList.remove('active');
                    // span.clasList.add('fade');
                // },)
            // })
        // })
// })